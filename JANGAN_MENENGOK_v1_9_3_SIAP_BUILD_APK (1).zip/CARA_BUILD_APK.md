# JANGAN MENENGOK v1.9.3 — Android APK build

This project uses GitHub Actions to create an installable **debug APK**.

## Steps
1. Extract this ZIP.
2. Upload all extracted files and folders to a GitHub repository (branch `main` or `master`).
3. Open the repository's **Actions** tab.
4. Choose **Build JANGAN MENENGOK APK** and press **Run workflow**. It also runs automatically after a push to `main`/`master`.
5. When the run succeeds, open the run, scroll to **Artifacts**, and download `JANGAN-MENENGOK-v1.9.3-debug-apk`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on the Android phone. Allow installation from that source if Android asks.

Notes:
- This is a debug APK for testing/personal installation, not a Play Store release.
- The workflow builds an APK that supports Android's normal device architectures, including arm64; it does not create a signed release APK.
- Some JavaScript libraries loaded from external CDNs may still need an internet connection in the game.
